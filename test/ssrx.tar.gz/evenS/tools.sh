#!/bin/sh 
# Copyright (C) 2016 evenS

APP=ss-redir
appname=evenS
ss_config_file_path=/tmp/shadowsocks.json
cron_task_file_path=/evenS/hasfuckedGFW.sh
evenS_path=/evenS
evenS_bin_path=$evenS_path/bin
evenS_config_path=$evenS_path/config

ss_getconfig() {
    lan_ip=$(uci get network.lan.ipaddr)
#	wanip=$(lua -e "print(require'tw'.get_wan_ip())")
	local_ip=0.0.0.0
	mode=$(uci get $APP.$appname.mode)
	ss_server_name=$(uci get $APP.$appname.ss_server_name)
	ss_server_domain=$(uci get $APP.$ss_server_name.ss_server_ip)
	if [ "$ss_server_domain" != "${ss_server_domain#*[0-9].[0-9]}" ]; then
  		#echo IPv4
		ss_server_ip=$ss_server_domain
	elif [ "$ss_server_domain" != "${ss_server_domain#*:[0-9a-fA-F]}" ]; then
  		#echo IPv6
		ss_server_ip=$ss_server_domain
	else
		#echo domain
		ss_server_ip=$(nslookup $ss_server_domain 114.114.114.114 | awk '{print $3}' | tail -1)
		[ ! -n "$ss_server_ip" ] && ss_server_ip=$($evenS_bin_path/hostip $ss_server_domain 2>/dev/null | tail -1 )
	fi
	ss_server_port=$(uci get $APP.$ss_server_name.ss_server_port)
	ss_server_password=$(uci get $APP.$ss_server_name.ss_password)
	ss_local_port=$(uci get $APP.$appname.ss_local_port)
	ss_server_method=$(uci get $APP.$ss_server_name.ss_method)
	ss_protocol=$(uci get $APP.$ss_server_name.ss_protocol)
	ss_protocol_param=$(uci get $APP.$ss_server_name.ss_protocol_param)
	ss_obfs=$(uci get $APP.$ss_server_name.ss_obfs)
	ss_obfs_param=$(uci get $APP.$ss_server_name.ss_obfs_param)	
	ss_udp=$(uci get $APP.$appname.udp)
	ss_dns_mode=$(uci get $APP.$appname.ss_dns_mode)
	printf $ss_server_ip > /tmp/ss_server_ip
}

