#!/bin/sh 
# Copyright (C) 2016 evenS
tail -n100 /tmp/sscron.log > /tmp/sscron.log.copy ; mv -f /tmp/sscron.log.copy /tmp/sscron.log
trap "rm -rf '/tmp/evenS/cron.lock' ; exit" 1 2 3 8 9 14 15
mkdir -p "/tmp/evenS/"
if [ ! -e "/tmp/evenS/cron.lock" ]; then
	touch "/tmp/evenS/cron.lock"
#	echo "--------------------------------------------------------" >> /tmp/sscron.log
#	nslookup qq.com >/dev/null
#	if [ "$?" != 0 ];then
#		/evenS/shadowsocks.sh fast_restart_dns
#		echo `date +"%m-%d %H:%M"`" Shadowsock DNS restarted " >> /tmp/sscron.log
#	fi
#	sleep 5
	state=`curl -s http://hiwifi.com/cgi-bin/turbo/app/vendor/ss_ajax?act=state`
	server_ip=`cat /tmp/ss_server_ip`
	if [ `echo $state | grep -c "\"200\""` == 1 ]; then
		echo `date +"%m-%d %H:%M"`" Everything is ok" >> /tmp/sscron.log
	else
		sleep 10
		state=`curl -s http://hiwifi.com/cgi-bin/turbo/app/vendor/ss_ajax?act=state`
		if [ `echo $state | grep -c "\"200\""` != 1 ]; then
			/evenS/shadowsocks.sh restart
			echo `date +"%m-%d %H:%M"`" Shadowsock restarted " >> /tmp/sscron.log
		else
			echo `date +"%m-%d %H:%M"`" Everything is ok" >> /tmp/sscron.log
		fi
	fi 
	rm -rf '/tmp/evenS/cron.lock'
else
	exit
fi

