#!/bin/sh 
# Copyright (C) 2016 evenS

index=$1

domain=$(uci get ss-redir.$index.ss_server_ip)
if [ -z "$domain" ]; then
    ping="超时"
    loss=100
else
    result=$(ping $domain -c 3 -q -w 1 -W 1| tail -2 | awk -F "[/ ]" '{print $7}' | tr -d "%" )2>/dev/null

    if [ ! -z "$result" ]; then
        loss=$(echo $result | awk -F " " '{print $1}' )
        ping=$(echo $result | awk -F " " '{print $2}')
    fi

    if [ -z "$ping" ]; then
        ping="超时"
        loss=100
    fi
fi

json="{\"index\":\"$index\",\"ping\":\"$ping\",\"loss\":\"$loss\"}"

if [ -z "$2" ]; then
    printf $json
fi