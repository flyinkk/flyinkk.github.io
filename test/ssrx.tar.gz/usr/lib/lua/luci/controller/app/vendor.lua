--[[
]]--

module("luci.controller.app.vendor", package.seeall)

function index()
	local page   = node("app", "vendor")
	page.target  = firstchild()
	page.title   = _("")
	page.order   = 10
    	page.sysauth = "admin"
      	page.mediaurlbase = "/turbo-static/turbo/web"
        local superkey = (luci.http.getcookie("superkey"))
 	if superkey ~= nil then
       		page.sysauth_authenticator = "appauth"
	else
        	page.sysauth_authenticator = "htmlauth_web"
        end	
	page.index = true
	
	entry({"app"}, firstchild(), _(""), 700)
	entry({"app", "vendor"}, firstchild(), _(""), 700)
	entry({"app", "vendor", "ss_ajax"}, template("app/vendor/ss_ajax"), _("status"), 700 ,true)
	entry({"app", "vendor", "ss_main"}, template("app/vendor/ss_main"), _("status"), 700)
	entry({"app", "vendor", "ss_mobile"}, template("app/vendor/ss_mobile"), _("status"), 700)
	entry({"app", "vendor", "ss_web"}, template("app/vendor/ss_web"), _("status"), 700)
end
