#!/bin/sh
/evenS/shadowsocks.sh firewall