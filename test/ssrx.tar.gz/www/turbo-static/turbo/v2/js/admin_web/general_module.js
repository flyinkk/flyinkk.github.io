//PC页面部分的逻辑--通用部分
(function () {
    "use strict";
    //Openapi的调试工具
    //Openapi.setDebugModel(true, 0);

    //构造 读取数据类型 接口callback的处理对象
    var get_realspeed_callback = HiWiFi.constructReadCallback(function (rsp) {
        rsp = rsp || {};
        var data = rsp.data || {};
        var total = data.total;
        var details = data.details || [];
        if (!total) {
            return;
        }

        //1.全局右上角的实时流量显示
        var upstream = HiWiFi.formatSize(total.upload_speed + "b", "KB", 0);
        var downstream = HiWiFi.formatSize(total.download_speed + "b", "KB", 0);

        var up_text = upstream + " KB/s";
        var down_text = downstream + " KB/s";
        var unit = "KB";
        if (unit === "KB" && (upstream >= 1000 || downstream >= 1000)) {
            up_text = HiWiFi.formatSize(upstream + "KB", "MB") + "MB/s";
            down_text = HiWiFi.formatSize(downstream + "KB", "MB") + "MB/s";
            unit = "MB";
        }
        //显示全局实时流量
        $('#upstream').html(up_text);
        $('#downstream').html(down_text);

        //2.向拥有traffic_info对象的dataStore更新属性
        if (!HiWiFi.dataStore.checkObjInStore("traffic_info")) {
            return;
        }
        //更新实时总流量，与需要流量信息的页面，约定“traffic_info”为缓存在dataStore的对象
        var real_time_traffic = HiWiFi.formatSize(total.download_speed + "b", "B");
        var real_time_traffic_byte = real_time_traffic;
        var real_time_unit = "B";
        if (real_time_unit === "B") {
            real_time_traffic = HiWiFi.formatSize(real_time_traffic + "B", "KB", 0);
            real_time_unit = "KB";
        }
        if (real_time_unit === "KB" && real_time_traffic >= 1000) {
            real_time_traffic = HiWiFi.formatSize(real_time_traffic + "KB", "MB");
            real_time_unit = "MB";
        }

        var device_traffic_info = {}; //设备流量的数组，转换成以mac为key的对象
        var device_unit = "KB";
        var device_up = "";
        var device_down = "";
        var i = 0;
        for (i in details) {
            device_unit = "KB";
            device_up = HiWiFi.formatSize(details[i].upload_speed + "b", "KB", 0);
            device_down = HiWiFi.formatSize(details[i].download_speed + "b", "KB", 0);
            if (device_unit === "KB" && (device_up >= 1000 || device_down >= 1000)) {
                device_up = HiWiFi.formatSize(device_up + "KB", "MB");
                device_down = HiWiFi.formatSize(device_down + "KB", "MB");
                device_unit = "MB";
            }
            device_traffic_info[HiWiFi.formatMacAddress(details[i].mac || "", true)] = {
                up: device_up,
                down: device_down,
                unit: device_unit
            };
        }
        HiWiFi.dataStore.updateData("traffic_info", {
            real_time_traffic_byte: real_time_traffic_byte, //单位B
            real_time_traffic: real_time_traffic,
            real_time_unit: real_time_unit
        });
        HiWiFi.dataStore.updateData("device_traffic_info", device_traffic_info);
    });
    //获取当前支持语言列表
    function getSupportLanguage(successCallback, errorCallback) {

        var callbacks = HiWiFi.constructReadCallback(successCallback, errorCallback);
        var request_configs = {
            version: "v1"
        };
        return Openapi.call("service.twx.get_i18n_support_language", null, request_configs, callbacks);
    }
    //设置语言
    function setLanguage(request_data, successCallback, errorCallback) {
        var callbacks = HiWiFi.constructReadCallback(successCallback, errorCallback);
        var request_configs = {
            version: "v1"
        };
        Openapi.call("service.twx.set_i18n_language", request_data, request_configs, callbacks);
    }

    function roundRobinUpdateData(time_out) {
        var request_configs = {
            version: "v1"
        };
        //如果路由器不是lan端直连的情况下
        if (!HiWiFi.isDirectConnectRouterByLan()) {
            HiWiFi.addTimerToGlobal(setTimeout(function () {
                Openapi.call("network.ipstat.get_realspeed", null, request_configs, get_realspeed_callback);
                roundRobinUpdateData();
            }, 4000));
            return;
        }
        //正常情况下
        time_out = time_out || 5000;
        //使用repeatCall
        HiWiFi.addTimerToGlobal(setTimeout(function () {
            request_configs.repeat_call = {
                interval: 2, //推送频率，由于流量接口刷新频率限制，设置为2s
                count: 20 //每请求一次将连续推送20次
            };
            Openapi.repeatCall("network.ipstat.get_realspeed", request_configs, get_realspeed_callback);
            roundRobinUpdateData(35000);
        }, time_out));
    }
    roundRobinUpdateData();
    /*
     *******************************action*******************************
     */
    //跳转到mobile页面
    $("#jump_mobile").on("click", function () {
        HiWiFi.setClientType("mobile");
        var request_uri = "/cgi-bin/turbo/admin_mobile";
        var stok = Openapi.getStok();
        if (stok) {
            request_uri = "/cgi-bin/turbo" + stok + "/admin_mobile";
        }
        location.href = request_uri;
    });
    //点击修改局域网ip按钮事件
    $("body").delegate('#lan_ip', 'click', function (event) {
        var stok = Openapi.getStok();
        var pathname = location.pathname;
        var is_system_view = !!pathname.match("admin_web\/system");
        if (is_system_view) {
            $("#lan_ip_setup_bt").click();
        } else {
            //局域网IP地址
            window.location.href = "/cgi-bin/turbo" + stok + "/admin_web/system#model=lan_ip_setup";
        }

    });

    //向页面size变换事件添加回调
    HiWiFi.addViewChangeCallback(function () {
        $("#right_part").outerHeight($("#right_part").parent().height());
        $(".J_system_restart").parent().css("bottom", "20px");
        $(".password-tip").css({
            top: $("#modify_password").offset().top + 7,
            left: $("#modify_password").offset().left - 100
        });
    });
    //重启按钮点击事件
    $(".J_system_restart").on("click", function () {
        //获取 重构的写入数据类型 接口callback的公共的默认处理对象
        var callbacks = HiWiFi.constructWriteCallback(function () {
            HiWiFi.showRouteRestartTip();
        });
        HiWiFi.popDialog({
            type: "confirm",
            title: [HiWiFi.i18n.prop("g_reboot_confirm"), HiWiFi.i18n.prop("g_reboot_tip")],
            content: "",
            button: [{
                name: HiWiFi.i18n.prop("g_ok"),
                callback: function () {
                    //停止其它现在正在进行的动作
                    Openapi.cancelRequest();
                    HiWiFi.stopTimerFromGlobal();
                    //执行重启动作
                    var request_configs = {
                        version: "v1"
                    };
                    Openapi.call("system.reboot", null, request_configs, callbacks);
                }
            }, {
                name: HiWiFi.i18n.prop("g_cancel"),
                callback: function () {
                    HiWiFi.popDialog();
                }
            }]
        });
    });
    //登出按钮点击事件
    $("#logout").on("click", function () {
        var stok = Openapi.getStok();
        Openapi.cancelRequest();
        //登出
        $.getJSON("/cgi-bin/turbo" + stok + "/api/login/logout_admin")
            .always(function () {
                location.replace("/cgi-bin/turbo/admin_web/");
            });
    });
    //修改密码按钮点击事件
    $("#modify_password").on("click", function () {
        var stok = Openapi.getStok();
        var pathname = location.pathname;
        var is_system_view = !!pathname.match("admin_web\/system");
        if (is_system_view) {
            $("#password_setup_bt").click();
        } else {
            //修改密码
            window.location.href = "/cgi-bin/turbo" + stok + "/admin_web/system#model=password_setup";
        }
    });
    //左侧菜单栏，点击跳转前，先停掉当前正在进行的其它动作
    $(".J_twx_view").on("click", function () {
        HiWiFi.stopTimerFromGlobal();
        Openapi.cancelRequest();
        return true;
    });
    //兼容safari 浏览器 触摸没事件
    $("body").on("touchstart", function () {
        //safari浏览器需要点击两次才能触发点击事件
    });
    //判断是否显示右上角默认密码提示
    if (window.g_is_default_password) {
        window.g_default_password = window.g_default_password || "admin";
        $("#password_tip").children(':eq(0)').children(":eq(1)").html(HiWiFi.i18n.prop("web_password_admin_tip", window.g_default_password));
        $(".J_password_tip").show();
        $('.J_password_tip').hover(function () {
            var $tipPop = $('#password_tip');
            var $this = $(this),
                l = $this.offset().left - 70,
                t = $this.offset().top + 5;
            $tipPop.css({
                'left': l + 'px',
                'top': t + 'px'
            }).show();
        }, function () {
            $('#password_tip').hide();
        });
    }
    //国际化言语选择弹层
    function languagePopShow($this, $languagePop) {
        $('.G-language-pop').css({
            'left': $this.offset().left - ($languagePop.outerWidth() / 2 - $this.outerWidth() / 2) + 'px',
            'top': $this.offset().top - $languagePop.outerHeight() - 10 + 'px'
        }).show();
    }
    $('.J_language_select').css("visibility", "visible");
    $('.J_language_select').click(function () {
        if ($('.G-language-pop').css("display") === "block") {
            $('.G-language-pop').hide();
            return;
        }
        var $this = $(this);
        var $language_pop = $('.G-language-pop');
        if ($language_pop.find('li').length) {
            languagePopShow($this, $language_pop);
            return;
        }
        languagePopShow($this, $language_pop);


        getSupportLanguage(function (rsp) {
            rsp = rsp || {};
            var data = rsp.data || {};
            var html = "";
            $.each(data.supports, function (i, v) {
                html += '<li><a';
                if (window.g_current_language === v) {
                    html += ' style="font-weight:bold"';
                }
                html += ' href="javascript:;" data=' + v + '>' + HiWiFi.i18n.prop("g_" + v) + '</a></li>';
            });
            $language_pop.find('ul').html(html);
            languagePopShow($this, $language_pop);
        });
    });
    $('body').delegate('.G-language-pop a', 'click', function () {
        var language = $(this).attr('data');
        var request_data = {
            language: language
        };
        setLanguage(request_data, function () {
            $('.G-language-pop').hide();
            window.location.reload(true);
        });
    });
}());